import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
import { mockupPreviewPlugin } from "./mockupPreviewPlugin";

const isBuild = process.env.NODE_ENV === "production";

const rawPort = process.env.PORT;
const port = isBuild ? 0 : (() => {
  if (!rawPort) throw new Error("PORT environment variable is required but was not provided.");
  const p = Number(rawPort);
  if (Number.isNaN(p) || p <= 0) throw new Error(`Invalid PORT value: "${rawPort}"`);
  return p;
})();

const basePath = isBuild ? "/" : (() => {
  if (!process.env.BASE_PATH) throw new Error("BASE_PATH environment variable is required but was not provided.");
  return process.env.BASE_PATH;
})();

export default defineConfig({
  base: basePath,
  plugins: [
    mockupPreviewPlugin(),
    react(),
    tailwindcss(),
    runtimeErrorOverlay(),
    ...(process.env.NODE_ENV !== "production" &&
    process.env.REPL_ID !== undefined
      ? [
          await import("@replit/vite-plugin-cartographer").then((m) =>
            m.cartographer({
              root: path.resolve(import.meta.dirname, ".."),
            }),
          ),
        ]
      : []),
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "src"),
    },
  },
  root: path.resolve(import.meta.dirname),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist"),
    emptyOutDir: true,
  },
  server: {
    port,
    host: "0.0.0.0",
    allowedHosts: true,
    fs: {
      strict: true,
    },
  },
  preview: {
    port,
    host: "0.0.0.0",
    allowedHosts: true,
  },
});
